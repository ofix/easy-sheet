# browserify test

First run

```js
npm install jquery-browserify
```

Then run

```js
browserify main.js > bundle.js
```

Then open index.html and console and scroll with the mousewheel. Should see the events being logged.
